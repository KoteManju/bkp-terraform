# Terraform Module for Private Registry - AWS S3 Static website
- This module provisions AWS S3 buckets configured for static website hosting.
- This will be a demo S3 module

